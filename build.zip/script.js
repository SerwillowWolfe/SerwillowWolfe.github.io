vkBridge.send('VKWebAppInit', {});
// чтобы ловить события в консоль:
vkBridge.subscribe((e) => {
  if(e.detail.type=="VKWebAppGetUserInfoResult"){
    let userId=e.detail.data.id;
    document.getElementById('prizeZoneTxt').innerText=userId;
  }
});

vkBridge.send("VKWebAppGetUserInfo");

let canvas = document.getElementById('roulette');
let ctx = canvas.getContext('2d');
let inProgress=false;

function randomInteger(min, max) {
  // случайное число от min до (max+1)
  let rand = min + Math.random() * (max + 1 - min);
  return Math.floor(rand);
}

let renderer=new Renderer();
let camera=new Camera(0, -3, 10000, 300);
renderer.addCam(camera);

let gameWorldObjects=new Array();

for (i=0; i<50; i++){
    let chance=randomInteger(1, 100);
     if(chance<=70){
        obj=new GameObject(i*canvas.height, 0, canvas.height, canvas.height, "src/smallPrize.png", false, false, false, 1000000);
        obj.prizeType="small";
     }
     if(chance>70 && chance<=85){
        obj=new GameObject(i*canvas.height, 0, canvas.height, canvas.height, "src/mediumPrize.png", false, false, false, 1000000);
        obj.prizeType="medium";
     }
     if(chance>85 && chance<=95){
        obj=new GameObject(i*canvas.height, 0, canvas.height, canvas.height, "src/bigPrize.png", false, false, false, 1000000);
        obj.prizeType="big";
     }
     if(chance>95){
        obj=new GameObject(i*canvas.height, 0, canvas.height, canvas.height, "src/superPrize.png", false, false, false, 1000000);
        obj.prizeType="super";
     }
     gameWorldObjects[i]=obj;
     renderer.addObject(obj);
}

function render(){
    renderer.update(ctx, renderer);
    if(renderer.objects[0].speedX>=0){
        let dot=new Dot(canvas.width/2, canvas.height/2);
        let ids=renderer.countDrawbleObjects(0);
        let objects=renderer.getDotObjects(dot, renderer, ids);
        let prizeObject=renderer.objects[objects[0]];
        /*
        1. при покупке часа на Ps + пол часа бесплатно
        2. при покупке часов в гейминге + час бесплатно
        3. двойное кол-во кубков при покупке часов/пакетов
        */
        let k=randomInteger(1, 3);
        let prizeTxt="";
        switch (prizeObject.prizeType){
            case "small":
                switch(k){
                    case 1:
                        prizeTxt="при покупке часа на Ps + пол часа бесплатно";
                    break;
                    case 2:
                        prizeTxt="при покупке часов в гейминге + час бесплатно";
                    break;
                    case 3:
                        prizeTxt="двойное кол-во кубков при покупке часов/пакетов";
                    break;
                }
            break;
            case "medium":
                switch(k){
                    case 1:
                        prizeTxt="1 чел из 2 получает бесплатно то, что покупаешь ты";
                    break;
                    case 2:
                        prizeTxt="50% скидка на консольный пакет Топ";
                    break;
                    case 3:
                        prizeTxt="50 кубков на аккаунт";
                    break;
                }
            break;
            case "big":
                switch(k){
                    case 1:
                        prizeTxt="100 кубков на аккаунт";
                    break;
                    case 2:
                        prizeTxt="скидка 50% для компании из 3 человек";
                    break;
                    case 3:
                        prizeTxt="скидка 50% на консольный пакет ночь";
                    break;
                }
            break;
            case "super":
                switch(k){
                    case 1:
                        prizeTxt="3 бесплатных часа в гейминг зоне";
                    break;
                    case 2:
                        prizeTxt="2 часа бесплатно на PS 4";
                    break;
                    case 3:
                        prizeTxt="2 бесплатных часа в вип зоне";
                    break;
                }
            break;
        }
        document.getElementById('prizeZoneTxt').innerText=prizeTxt;
        clearInterval(inter);
        inProgress=false;
    }else{
        for(i=0; i<50; i++){
            gameWorldObjects[i].speedX+=0.03;
        }
    }
}

function roll(){
    if(!inProgress){
        renderer=new Renderer();
        renderer.addCam(camera);
        gameWorldObjects=new Array();
        for (i=0; i<50; i++){
            let chance=randomInteger(1, 100);
             if(chance<=70){
                obj=new GameObject(i*canvas.height, 0, canvas.height, canvas.height, "src/smallPrize.png", false, false, false, 1000000);
                obj.prizeType="small";
             }
             if(chance>70 && chance<=85){
                obj=new GameObject(i*canvas.height, 0, canvas.height, canvas.height, "src/mediumPrize.png", false, false, false, 1000000);
                obj.prizeType="medium";
             }
             if(chance>85 && chance<=95){
                obj=new GameObject(i*canvas.height, 0, canvas.height, canvas.height, "src/bigPrize.png", false, false, false, 1000000);
                obj.prizeType="big";
             }
             if(chance>95){
                obj=new GameObject(i*canvas.height, 0, canvas.height, canvas.height, "src/superPrize.png", false, false, false, 1000000);
                obj.prizeType="super";
             }
             gameWorldObjects[i]=obj;
             renderer.addObject(obj);
        }

        window.inter=setInterval(render, 15);

        inProgress=true;

        for(i=0; i<50; i++){
            gameWorldObjects[i].speedX=-20;
        }
    }

}

window.onload=function(){
    renderer.update(ctx, renderer);
}
